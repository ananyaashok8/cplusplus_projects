# Component constraints for C:\Users\91819\Documents\HDA_Sem2\EAA\Lab\Workspace01\Workspace03\electronicClock_v3.cydsn\electronicClock_v3.cydsn\electronicClock_almostFinal.cydsn\electronicClock.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\91819\Documents\HDA_Sem2\EAA\Lab\Workspace01\Workspace03\electronicClock_v3.cydsn\electronicClock_v3.cydsn\electronicClock_almostFinal.cydsn\electronicClock.cydsn\electronicClock.cyprj
# Date: Fri, 01 Jul 2022 21:58:07 GMT
