-- ======================================================================
-- autosar_01.ctl generated from autosar_01
-- 05/27/2022 at 23:21
-- This file is auto generated. ANY EDITS YOU MAKE MAY BE LOST WHEN THIS FILE IS REGENERATED!!!
-- ======================================================================

-- PSoC Clock Editor
-- Directives Editor
-- Analog Device Editor
