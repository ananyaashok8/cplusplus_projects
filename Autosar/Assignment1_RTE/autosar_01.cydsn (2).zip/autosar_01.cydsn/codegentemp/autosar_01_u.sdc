# Component constraints for C:\Users\91819\Documents\HDA_Sem2\EAA\Lab\Workspace01\Workspace01\autosar_01.cydsn\TopDesign\TopDesign.cysch
# Project: C:\Users\91819\Documents\HDA_Sem2\EAA\Lab\Workspace01\Workspace01\autosar_01.cydsn\autosar_01.cyprj
# Date: Fri, 27 May 2022 21:21:40 GMT
